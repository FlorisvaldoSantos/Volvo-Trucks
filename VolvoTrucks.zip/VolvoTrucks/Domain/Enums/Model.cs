﻿namespace Domain.Enums
{
    public enum Model
    {
        FH = 1,
        FM = 2,
        VM = 3
    }
}
